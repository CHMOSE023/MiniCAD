#include "Picking.h"
#include "Render/Viewport/Camera.h"
#include "App/Scene/Scene.h"

using namespace DirectX;

namespace MiniCAD
{ 
    // 点选：返回离相机最近的对象ID
    Object::ObjectID Picking::PickPoint(const Scene& scene, const IViewContext& view, float mouseX, float mouseY) const
    {
        // 屏幕坐标 → 世界坐标
        XMFLOAT3 worldPos = view.ScreenToWorld(mouseX, mouseY);
        XMVECTOR mouse    = XMVectorSet(worldPos.x, worldPos.y, 0.f, 0.f);


        // 拾取容忍阈值（世界空间单位）
        // 需要根据缩放换算：屏幕 5 像素对应多少世界单位
        constexpr float kPixelTolerance = 5.f;
        XMFLOAT3 p0 = view.ScreenToWorld(mouseX, mouseY);
        XMFLOAT3 p1 = view.ScreenToWorld(mouseX + kPixelTolerance, mouseY);
        float tolerance = fabsf(p1.x - p0.x); // 5 像素对应的世界单位

        Object::ObjectID bestID = Object::InvalidID;
        float            bestDist = FLT_MAX;

        for (auto id : scene.GetAllIDs())
        {
            const auto* obj = scene.GetEntity(id);
            if (!obj) continue;

            if (obj->IsKindOf<LineEntity>())
            {
                const auto* line = static_cast<const LineEntity*>(obj);
                const auto& geo = line->GetLine();

                float dist = PointToSegmentDistance(
                    mouse,
                    XMVectorSet(geo.Start.x, geo.Start.y, 0.f, 0.f),
                    XMVectorSet(geo.End.x, geo.End.y, 0.f, 0.f));

                if (dist < tolerance && dist < bestDist)
                {
                    bestDist = dist;
                    bestID = id;
                }
            }
        }

        return bestID; 
    }

    // 点到线段的最短距离
    float Picking::PointToSegmentDistance(XMVECTOR p, XMVECTOR a, XMVECTOR b) const
    {
        XMVECTOR ab = XMVectorSubtract(b, a);
        XMVECTOR ap = XMVectorSubtract(p, a);

        float lenSq = XMVectorGetX(XMVector2Dot(ab, ab));
        if (lenSq < 1e-10f)
        {
            // 线段退化为点
            return XMVectorGetX(XMVector2Length(ap));
        }

        // t = dot(ap, ab) / dot(ab, ab)，clamp 到 [0,1]
        float t = XMVectorGetX(XMVector2Dot(ap, ab)) / lenSq;
        t = std::clamp(t, 0.f, 1.f);

        // 最近点
        XMVECTOR closest = XMVectorAdd(a, XMVectorScale(ab, t));
        XMVECTOR diff = XMVectorSubtract(p, closest);

        return XMVectorGetX(XMVector2Length(diff));
    }
}