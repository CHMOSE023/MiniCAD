#include "app/Editor.h"
#include "ui/Windows/MainWindow.h" 
#include <windows.h>
#include <cstdio>

int main() {

    // GetModuleHandleW(nullptr) ���ص�ǰ���̵� HINSTANCE
    HINSTANCE hInstance = GetModuleHandle(nullptr);

    MiniCAD::MainWindow window;
    if (!window.Create(hInstance, L"MiniCAD", 1280, 720)) {
        return -1;
    }

    window.Show(SW_SHOWDEFAULT);   // SW_SHOWDEFAULT �� NULL ���������

    // ��Ϣѭ��
    MSG msg = {};
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return static_cast<int>(msg.wParam);
}